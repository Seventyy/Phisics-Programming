﻿using System;
using GXPEngine;

public class Ball : EasyDraw
{
    private Vec2 _position;
    private Vec2 _velocity;
    private Vec2 _displacement;

    private int _radius;

    //Sprite background = new Sprite("backgrond.png");

    public Vec2 Position
    {
        get { return _position; }
        set
        {
            _position = value;
            UpdateScreenPosition();
        }
    }

    public Vec2 Velocity
    {
        get { return _velocity; }
        set { _velocity = value; }
    }

    public Vec2 Displacement
    {
        get { return _displacement; }
    }

    public int Radius
    {
        get { return _radius; }
        set { _radius = value; }
    }


    public Ball(int radius, Vec2 position) : base(radius * 2 + 1, radius * 2 + 1)
    {
        _radius = radius;
        Position = position;

        SetOrigin(_radius, _radius);

        Draw(255, 255, 255);
    }

    private void Draw(byte red, byte green, byte blue)
    {
        Fill(red, green, blue);
        //Stroke(red, green, blue);
        Ellipse(_radius, _radius, 2 * _radius, 2 * _radius);
    }

    void FollowMouse()
    {
        _position.SetXY(Input.mouseX, Input.mouseY);
    }

    private void UpdateScreenPosition()
    {
        x = _position.x;
        y = _position.y;
    }

    public void Step()
    {
        _displacement = _velocity * 1 / 60;
        Position += _displacement;
        //FollowMouse();
    }
}
