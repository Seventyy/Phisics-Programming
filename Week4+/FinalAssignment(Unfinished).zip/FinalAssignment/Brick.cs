﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    internal class Brick: EasyDraw, BallCollider
    {
        private Vec2 _position;
        private Vec2 _size;

        public Brick(Vec2 position, Vec2 size) : base((int)size.x+1, (int)size.y+1)
        {
            _position = position;
            _size = size;

            SetOrigin(0, 0);
            Draw(255, 0, 255);
            UpdateScreenPosition();
        }

        public bool isColliding(Ball ball)
        {
            if (ball == null) return false;

            Vec2 pos = ball.Position;
            float r = ball.Radius;
            float r_sq = ball.Radius * ball.Radius;

            float left = _position.x;
            float right = _position.x + _size.x;
            float top = _position.y;
            float bottom = _position.y + _size.y;

            Vec2 top_left = new Vec2(left, top);
            Vec2 top_right = new Vec2(right, top);
            Vec2 bottom_left = new Vec2(left, bottom);
            Vec2 bottom_right = new Vec2(right, bottom);

            if (pos.x < left - r ||
                pos.x > right + r ||
                pos.y < top - r ||
                pos.y > bottom + r)
            {
                return false;
            }

            if ((pos >= top_left + new Vec2(-r, 0) && pos <= bottom_right + new Vec2(r, 0)) ||
                (pos >= top_left + new Vec2(0, -r) && pos <= bottom_right + new Vec2(0, r)))
            {
                Console.WriteLine("Jest kolizja ze środkiem" + DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond);
                return true;
            }

            if ((pos - top_left).LengthSquared() <= r_sq ||
                (pos - top_right).LengthSquared() <= r_sq ||
                (pos - bottom_left).LengthSquared() <= r_sq ||
                (pos - bottom_right).LengthSquared() <= r_sq)
            {
                Console.WriteLine("Jest kolizja ze kątem" + DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond);
                return true;
            }
            
            return false;
        }

        public void ResolveCollision(Ball ball)
        {
            Vec2 last_pos = ball.Position - ball.Velocity;
            float r = ball.Radius;
            float r_sq = ball.Radius * ball.Radius;

            float left = _position.x;
            float right = _position.x + _size.x;
            float top = _position.y;
            float bottom = _position.y + _size.y;

            Vec2 top_left = new Vec2(left, top);
            Vec2 top_right = new Vec2(right, top);
            Vec2 bottom_left = new Vec2(left, bottom);
            Vec2 bottom_right = new Vec2(right, bottom);

            Vec2 normal;
            Vec2 corner;

            if (last_pos.y >= last_pos.x + _position.y - _position.x &&
                last_pos.y <= -last_pos.x + _position.y + _position.x + _size.y)
            {
                // left trapezoid
                normal = new Vec2(-1, 0);
                corner = top_left;
            }
            else if (last_pos.y >= last_pos.x + _position.y - _position.x + _size.y - _size.x &&
                last_pos.y >= -last_pos.x + _position.y + _position.x + _size.y)
            {
                // bottom trapezoid
                normal = new Vec2(0, 1);
                corner = bottom_left;
            }
            else if (last_pos.y <= last_pos.x + _position.y - _position.x + _size.y - _size.x &&
                last_pos.y >= -last_pos.x + _position.y + _position.x + _size.x) 
            {
                // right trapezoid
                normal = new Vec2(1, 0);
                corner = bottom_right;
            }
            else
            {
                // top trapezoid
                normal = new Vec2(0, -1);
                corner = top_right;
            }


            float distance = (ball.Position - corner).Dot(normal);

            ball.Position -= ball.Displacement.Normalized() * (ball.Radius - distance) * ball.Displacement.Length() / -ball.Displacement.Dot(normal);
            ball.Velocity = ball.Velocity.Reflected(normal);




            //if (pos.x < left)
            //{
            //    if (pos.y < top)
            //    {
            //        // Position is in the top-left space
            //    }
            //    else if (pos.y > bottom)
            //    {
            //        // Position is in the bottom-left space
            //    }
            //    else
            //    {
            //        // Position is in the left space
            //    }
            //}
            //else if (pos.x > right)
            //{
            //    if (pos.y < top)
            //    {
            //        // Position is in the top-right space
            //    }
            //    else if (pos.y > bottom)
            //    {
            //        // Position is in the bottom-right space
            //    }
            //    else
            //    {
            //        // Position is in the right space
            //    }
            //}
            //else 
            //{
            //    if (pos.y < top)
            //    {
            //        // Position is in the top space
            //    }
            //    else if (pos.y > bottom)
            //    {
            //        // Position is in the bottom space
            //    }
            //    else
            //    {
            //        Console.WriteLine("This shouldnt happen");
            //    }
            //}

        }

        private void Draw(byte red, byte green, byte blue)
        {
            Stroke(red, green, blue);
            Rect(_size.x/2, _size.y/2, _size.x, _size.y);
        }
        void UpdateScreenPosition()
        {
            x = _position.x;
            y = _position.y;
        }
    }
}
