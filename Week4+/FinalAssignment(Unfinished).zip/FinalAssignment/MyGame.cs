using System;
using GXPEngine;
using System.Drawing;
using System.Collections.Generic;

public class MyGame : Game
{	
	static void Main() {
		new MyGame().Start();
	}

    Ball ball;
    List<BallCollider> colliders = new List<BallCollider>();

    Vec2 clickPos;

    public MyGame() : base(800, 600, false, false)
    {
        colliders.Add(new BorderWall(new Vec2(width - 50, 10), new Vec2(width - 10, height - 10)));
        colliders.Add(new BorderWall(new Vec2(50, 10), new Vec2(10, height - 10), true));
        colliders.Add(new BorderWall(new Vec2(50, 10), new Vec2(width - 50, 10)));

        colliders.Add(new Brick(new Vec2(200, 150), new Vec2(400, 300)));

        foreach (BallCollider collider in colliders)
        {
            AddChild(collider as GameObject);
        }

        ball = new Ball(10, new Vec2(487, 50));
        ball.Velocity = new Vec2(-400,300);
        AddChild(ball);

    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            clickPos = new Vec2(Input.mouseX, Input.mouseY);
            ball = new Ball(10, clickPos);
            AddChild(ball);
        }
        if (Input.GetMouseButtonUp(0))
        {
            ball.Velocity = (new Vec2(Input.mouseX, Input.mouseY) - clickPos) * 2;
        }


        ball?.Step();
        foreach (BallCollider collider in colliders)
        {
            if (collider.isColliding(ball))
            {
                collider?.ResolveCollision(ball);
            }
        }
    }

}

